﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace $safeprojectname$
{
    // Lógica de configuración global de la aplicación
    public partial class App : Application
    {
    }

}
